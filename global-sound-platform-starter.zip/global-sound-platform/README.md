# Global Sound Platform

Fresh foundation for Global Sound 3000+.

## Stack
- Frontend: existing mobile-first HTML app in `frontend/`
- Backend: Node.js + Express
- Database/Auth/Storage: Supabase (PostgreSQL, Auth, Storage)
- Later integrations: LiveKit for live audio/video; payment provider selected after country and merchant onboarding checks.

## Local backend setup
1. Install Node.js 20+.
2. `cd backend && npm install`
3. Copy `.env.example` to `.env` and fill in Supabase values.
4. `npm run dev`
5. Open `http://localhost:3000/health`

Never commit `.env`, service-role keys, payment secrets, or private credentials.

## Initial status
This is a secure project scaffold, not a deployed production service. Authentication, music uploads, live streaming, payments, and admin operations must be implemented and tested before launch.
